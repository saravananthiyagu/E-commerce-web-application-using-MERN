import React, { useContext,useState } from "react";
import './cartitems.css';
import { ShopContext } from "../../Context/ShopContext";
import remove_icon from '../Assets/cart_cross_icon.png';

function CartItems(){
    const {getTotalCartAmount,all_product,cartItem,removeFromCart} = useContext(ShopContext);
    
    const [address,setAddress] = useState([]);
    const [cname,setCname] = useState([]);
    const [phone,setPhone] = useState([]);

    // eslint-disable-next-line no-unused-vars
    const [cartdetails,setCartDetails] = useState({
        name:"",
        price:"",
        quantity:"",
        cname:"",
        address:"",
        phone:""
    })

    const addcartdetails = async() =>{
        // eslint-disable-next-line no-lone-blocks, array-callback-return
        {all_product.map(async (e)=>{
            if(localStorage.getItem('auth-token')){
                if(cartItem[e.id]>0){
                    cartdetails.name = e.name;
                    cartdetails.price = e.new_price;
                    cartdetails.quantity = cartItem[e.id];
                    cartdetails.cname = cname;
                    cartdetails.address = address;
                    cartdetails.phone = phone;
                    console.log(cartdetails);
                    await fetch('http://localhost:4000/orders',{
                        method:'POST',
                        headers:{
                            Accept:'application/json',
                            'Content-Type' : 'application/json',
                        },
                        body:JSON.stringify(cartdetails),
                    }).then((resp)=>resp.json()).then((data)=>{
                        if(data.success){
                            var options = {
                                key:"rzp_test_iIitSHaG5chKOx",
                                key_secret:"FbnGi0snkefcydcM9hpZjnBm",
                                amount:getTotalCartAmount()*100,
                                currency:"INR",
                                name:"Shopper",
                                description:"for purchasing an item",
                                handler:function(response){
                                    // eslint-disable-next-line no-useless-concat
                                    alert("Your order has been placed successfully, your product will be delivered in 4-5 business days.");
                                },
                                prefill:{
                                    name:<input type="text"/>,
                                    email:<input type="email"/>,
                                    contact:<input type="number"/>,
                                },
                                notes:{
                                    address:"razorpay office",
                                },
                                theme:{
                                    color:"#fff"
                                }
                            };
                            var pay = new window.Razorpay(options);
                            pay.open();
                        }else{
                            alert("order failed");
                        }       
                    })
                }}
                else{
                    
                }
        })}
    }


    return (
        <div className="cartitems">
            <div className="cartitems-format-main">
                <p>Products</p>
                <p>Title</p>
                <p>Price</p>
                <p>Quantity</p>
                <p>Total</p>
                <p>Remove</p>
            </div>
            <hr/>
            {all_product.map((e)=>{
                if(cartItem[e.id]>0){
                    return  <div>
                                <div className="cartitems-format-main cartitems-format">
                                    <img src={e.image} alt="" className="carticon-product-icon"/>
                                    <p>{e.name}</p>
                                    <p>₹{e.new_price}</p>
                                    <p className="cartitems-quantity">{cartItem[e.id]}</p>
                                    <p>₹{e.new_price*cartItem[e.id]}</p>
                                    <img className="cartitems-remove-icon" src={remove_icon} onClick={()=>{removeFromCart(e.id)}} alt=""/>
                                </div>
                    <hr/>
                    </div>
                }else{
                    return null;
                }
        })}
        <div className="cartitems-down">
            <div className="cartitems-total">
                <h1>cart Totals</h1>
                <div>
                    <div className="cartitems-total-item">
                        <p>Subtotal</p>
                        <p>₹{getTotalCartAmount()}</p>
                    </div>
                    <hr/>
                    <div className="cartitems-total-item">
                        <p>Shipping Fee</p>
                        <p>Free</p>
                    </div>
                    <hr/>
                    <div className="cartitems-total-item">
                        <h3>Total</h3>
                        <h3>₹{getTotalCartAmount()}</h3>
                    </div>
                    {(localStorage.getItem('auth-token'))?null:<p>Please login to place order</p>}
                </div>
                <div className="name">
                    <p>Name :</p>
                    <input type="text" value={cname} onChange={(e)=>{setCname(e.target.value)}} placeholder="name"/>
                </div>
                <div className="address">
                    <p>Address : </p>
                    <input type="text" value={address} onChange={(e)=>{setAddress(e.target.value)}} placeholder="Address" required/>
                </div>
                <div className="phone">
                    <p>Mobile number : </p>
                    <input type="text" placeholder="mobile number" maxLength={10} value={phone} onChange={(e)=>{setPhone(e.target.value)}}/>
                </div>
                <button onClick={()=>{addcartdetails()}}>CHECKOUT</button>
            </div>
        </div>
        </div>
    )
}

export default CartItems;