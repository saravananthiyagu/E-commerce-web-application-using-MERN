import React from "react";
import CartItems from "../Components/CartItems/CartItems";

function Cart(){
    return (
        <div>
            <CartItems/>
        </div>
    )
}

export default Cart;