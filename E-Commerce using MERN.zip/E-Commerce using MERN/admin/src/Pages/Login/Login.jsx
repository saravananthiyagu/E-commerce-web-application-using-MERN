// eslint-disable-next-line no-unused-vars
import React, { useState } from "react";
import './Login.css';
// eslint-disable-next-line no-unused-vars
import App from "../../App";
import { useNavigate } from "react-router-dom";

function Login(){

    const [formData,setFormData] = useState({
        id:"",
        password:""
    })

    const navigate = useNavigate();

    const changeHandler =(e)=>{
        setFormData({...formData,[e.target.name]:e.target.value});
    } 

    const login = async() =>{
        let responseData;
        await fetch('http://localhost:4000/adminlogin',{
            method:'POST',
            headers:{
                Accept:'application/json',
                'Content-Type':'application/json',
            },
            body:JSON.stringify(formData),
        }).then((response)=>response.json()).then((data)=>responseData=data)

        if(responseData.success){
            localStorage.setItem('auth-token',responseData.token);
            alert("Logged in");
            if(localStorage.getItem('auth-token')){
                navigate('/App');
            }
        }else{
            alert("Error occured");
        }
    }

    return (
        <div className="login">
            <h1>Admin Login</h1>
            <div className="username">
                <p>Username : </p>
                <input name="id" type="text" value={formData.id} onChange={changeHandler} placeholder="username"/>
            </div>
            <div className="password">
                <p>Password : </p>
                <input name="password" type="password" value={formData.password} onChange={changeHandler} placeholder="password"/>
            </div>
            <br></br>
            <button onClick={()=>{login()}}>Login</button>
            {/*localStorage.getItem('auth-token')?<App/>:null*/}
        </div>
    )
}

export default Login;