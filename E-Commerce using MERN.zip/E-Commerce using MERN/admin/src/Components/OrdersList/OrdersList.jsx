/* eslint-disable no-unused-vars */
import React,{useState,useEffect} from 'react';
import './OrdersList.css';

function OrdersList(){

    const [allorders, setAllOrders] = useState([]);

    const fetchInfo = async() =>{
        await fetch('http://localhost:4000/allorders').then((res)=>res.json()).then((data)=>setAllOrders(data));
    }

    useEffect(()=>{
        fetchInfo();
    },[])

    return (
        <div className='orderslist'>
           <h1>All orders List</h1>
           <div className='orderslist-formatmain'>
            <p>product</p>
            <p>price</p>
            <p>quantity</p>
            <p>Customer name</p>
            <p>address</p>
            <p>phone</p>
            <p>Ordered date</p>
           </div>
           <div className='orderslist-allproducts'>
            <hr/>
            {allorders.map((product,index)=>{
                return <>
                    <div key={index} className='orderslist-formatmain listproduct-format'>
                        <p>{product.name}</p>
                        <p>₹{product.price}</p>
                        <p>{product.quantity}</p>
                        <p>{product.cname}</p>
                        <p>{product.address}</p>
                        <p>{product.phone}</p>
                        <p>{product.date}</p>
                    </div>
                </>
            })}
           </div>
        </div>
    )
}

export default OrdersList;